package com.mx.productosService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
